# Assets — Exploring Expense Management

**Project slug:** `expense-mgmt`
**Portfolio section:** Older Projects (LazyPay / PayU Finance)
**Website project page:** `/work/expense-mgmt` or equivalent slug

> ⚠️ **Confidentiality note:** This project was a work in progress and had not been publicly released. Mark the project page with an appropriate confidential/NDA indicator. Do not include actual app screens.

---

## Naming Convention

All files follow the pattern: `{NN}_{role}_{display-hint}.svg`

| Part | Meaning |
|---|---|
| `NN` | Two-digit sequence number — defines the **order images appear** on the project page (01 = first/top) |
| `role` | What the image depicts |
| `display-hint` | Suggested CSS display treatment: `thumbnail`, `inline`, `full-width` |

---

## Files — In Display Order

### `01_cover_thumbnail.svg`
- **Sequence:** 1 — first image on the page; also used as the project card thumbnail
- **Placement:** Project card grid (Work index page) + hero area at top of project detail page
- **Display:** Full-width hero, `max-height: 480px`, `object-fit: cover`
- **Alt text:** `"Expense management concept with donut chart showing 30% of users don't track expenses, and three key statistics"`
- **Content:** Dark green-tinted cover with a donut chart (30% don't track expenses), three stat chips (40%, 33%, 14%), the main pitch statement "Manage your money", and project metadata
- **Notes:** Use as `thumbnail` field in `data/projects.ts`

### `02_user-research-stats_inline.svg`
- **Sequence:** 2 — appears in the "Researching User Needs" section
- **Placement:** Inline within the user research section, after the interview setup paragraph
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Five statistics from user research: 40% want to save more, 33% struggle with saving, 30% don't track expenses, 26% use a physical diary, 14% use an app"`
- **Content:** Five stat cards in a row; the top priority stat (40%) is highlighted in coral; remaining stats in neutral grey
- **Notes:** Place after the description of the demographic study; before quoting interview snippets

### `03_ia-framework_full-width.svg`
- **Sequence:** 3 — appears in the "Information Architecture" section
- **Placement:** Inline within the IA definition section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Expense information architecture tree: Expenses branches into Spends (everyday transactions), Bills and Subscriptions, and Upcoming Payments. Spends further splits into category types like Food and Travel."`
- **Content:** Tree diagram showing the IA hierarchy with colour-coded nodes; a "Key Rules" callout box explaining what does and does not count as an expense
- **Notes:** Place immediately after the paragraph introducing the IA decisions; this is the central intellectual output of the project

---

## Page Structure Reference

```
[Project Hero]
  01_cover_thumbnail.svg                  ← full-width hero

[Section: Analysing the Competition]
  text only (12-15 apps researched)

[Section: Researching User Needs]
  text paragraph (demo study + interviews)
  02_user-research-stats_inline.svg       ← full content width
  text (interview snippets/quotes)

[Section: Research Insights]
  text only (key findings)

[Section: Formulating the Main Pitch]
  text only ("Manage your money")

[Section: Information Architecture]
  text intro
  03_ia-framework_full-width.svg          ← full content width
  text (key IA decisions / bullet points)

[Section: Wireframes & Components]
  text only (NDA — screens not shown)

[Confidential notice at bottom of page]
```

---

## Design Tokens Used

| Token | Value |
|---|---|
| Background | `#FAFAFA` |
| Primary text | `#111111` |
| Muted text | `#737373` |
| Accent (coral) | `#FF4530` |
| Card background | `#F2F2F2` |
| Border | `#E0E0E0` |
| Cover background | `#0D1F0D` (dark green) |
