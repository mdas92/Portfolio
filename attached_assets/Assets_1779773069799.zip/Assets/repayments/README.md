# Assets — Improving Repayment Rates

**Project slug:** `repayments`
**Portfolio section:** Older Projects (LazyPay / PayU Finance)
**Website project page:** `/work/repayments` or equivalent slug

---

## Naming Convention

All files follow the pattern: `{NN}_{role}_{display-hint}.svg`

| Part | Meaning |
|---|---|
| `NN` | Two-digit sequence number — defines the **order images appear** on the project page (01 = first/top) |
| `role` | What the image depicts |
| `display-hint` | Suggested CSS display treatment: `thumbnail`, `inline`, `full-width` |

---

## Files — In Display Order

### `01_cover_thumbnail.svg`
- **Sequence:** 1 — first image on the page; also used as the project card thumbnail
- **Placement:** Project card grid (Work index page) + hero area at top of project detail page
- **Display:** Full-width hero, `max-height: 480px`, `object-fit: cover`
- **Alt text:** `"Phone notification mockup showing a before/after comparison of the repayment reminder: vague original versus a clear redesigned version showing amount, urgency, and late fee warning"`
- **Content:** Dark red-tinted cover with a phone mockup showing two notification states (before: vague; after: ₹2,450 due now with late fee warning); headline stats (45% of new users, 23% opened app but didn't pay); target improvement (+10% on-time repayment rate)
- **Notes:** Use as `thumbnail` field in `data/projects.ts`

### `02_problem-data_inline.svg`
- **Sequence:** 2 — appears near the top of the case study in the "What's the Problem?" section
- **Placement:** Inline within the problem definition section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Flow diagram showing 100% of new users breaking into 45% not repaying (split further into 23% who opened the app but didn't pay and 22% who didn't open at all) and 55% paying on time. Root causes listed: no urgency signals, late fee not visible, notification easy to ignore."`
- **Content:** Sankey-style breakdown of the user behaviour problem; root causes callout box
- **Notes:** Place immediately after the paragraph introducing the 45% statistic

### `03_solution-strategy_full-width.svg`
- **Sequence:** 3 — appears in the "Solution Strategy" section
- **Placement:** Inline within the solution strategy section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Three-column strategy framework: 01 Discoverability (redesigned notification placement and hierarchy), 02 Urgency (new bottom sheet after due date breach), 03 Transparency (surfaced late fees, clearer CTA)"`
- **Content:** Three equal columns showing the three-pronged solution strategy; each column has a numbered heading, problem description, and solution description; coral top accent bars
- **Notes:** Place after the paragraph introducing the three-pronged approach; before explaining individual solutions in detail

### `04_content-hierarchy_full-width.svg`
- **Sequence:** 4 — appears in the "Content-First Design Approach" section
- **Placement:** Inline within the content-first design methodology section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Prioritised table of notification content: Amount (essential), Due date (essential), Due status (essential), Penalties, Count, Product name — with example text and purpose for each"`
- **Content:** Six-row priority table showing the information hierarchy for the repayment notification component; essential items highlighted in coral; each row includes priority label, example copy, and purpose explanation
- **Notes:** Place after the paragraph about applying a content-first design approach; this shows the specific content decision-making process

---

## Page Structure Reference

```
[Project Hero]
  01_cover_thumbnail.svg                 ← full-width hero

[Section: What's the Problem?]
  text paragraph (45% stat + context)
  02_problem-data_inline.svg             ← full content width
  text (root causes list)

[Section: Business Goals]
  text only (+10% metric)

[Section: User Journey]
  text only (diagram described)

[Section: Solution Strategy]
  text intro
  03_solution-strategy_full-width.svg    ← full content width

[Section: Content-First Design Approach]
  text intro (notification redesign)
  04_content-hierarchy_full-width.svg    ← full content width
  text (outcome / what was built)

[Section: Results]
  text only (metrics if available)
```

---

## Design Tokens Used

| Token | Value |
|---|---|
| Background | `#FAFAFA` |
| Primary text | `#111111` |
| Muted text | `#737373` |
| Accent (coral) | `#FF4530` |
| Card background | `#F2F2F2` |
| Border | `#E0E0E0` |
| Cover background | `#2A0A06` (dark red-brown) |
