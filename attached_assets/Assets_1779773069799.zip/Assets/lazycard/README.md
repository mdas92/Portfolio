# Assets — UX Writing Review for LazyCard

**Project slug:** `lazycard`
**Portfolio section:** Older Projects (LazyPay / PayU Finance)
**Website project page:** `/work/lazycard` or equivalent slug

---

## Naming Convention

All files follow the pattern: `{NN}_{role}_{display-hint}.svg`

| Part | Meaning |
|---|---|
| `NN` | Two-digit sequence number — defines the **order images appear** on the project page (01 = first/top) |
| `role` | What the image depicts |
| `display-hint` | Suggested CSS display treatment: `thumbnail`, `inline`, `full-width` |

---

## Files — In Display Order

### `01_cover_thumbnail.svg`
- **Sequence:** 1 — first image on the page; also used as the project card thumbnail
- **Placement:** Project card grid (Work index page) + hero area at top of project detail page
- **Display:** Full-width hero, `max-height: 480px`, `object-fit: cover`
- **Alt text:** `"LazyCard credit card mockup with persona chips showing Hedonist and Attacker as target users"`
- **Content:** Dark-background cover with stylised credit card mockup; target persona chips (Defender, Hedonist ✓, Attacker ✓); stats bar (4 days, full app flow, target personas)
- **Notes:** Use as `thumbnail` field in `data/projects.ts`

### `02_user-personas_inline.svg`
- **Sequence:** 2 — appears in the "Understanding Users" section
- **Placement:** Inline within the user personas section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Three user persona cards: Defender (save for future), Hedonist (earn to enjoy, target), and Attacker (earn for future, target). Hedonist and Attacker are highlighted as LazyCard target groups."`
- **Content:** Three persona cards; Hedonist and Attacker highlighted in coral as the target group for LazyCard; each shows persona motto, description, and credit comfort level
- **Notes:** Place immediately after the paragraph explaining the persona study

### `03_user-journey_full-width.svg`
- **Sequence:** 3 — appears in the "Mapping the User Journey" section
- **Placement:** Inline within the user journey section, after the intro paragraph
- **Display:** Full content width, `max-width: 800px`; can be wider if layout permits
- **Alt text:** `"Four-stage user journey map for LazyCard: Awareness, Consideration, Onboarding, Activation — with descriptions and emotional states at each stage"`
- **Content:** Linear four-stage journey map with stage descriptions, connecting arrows, and emotion labels at the bottom of each card
- **Notes:** Place immediately after the "Mapping the user journey" heading and intro text; before the copy review section

### `04_copy-review_full-width.svg`
- **Sequence:** 4 — appears in the "Copy Review" section
- **Placement:** Inline within the designs and copy review section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Before and after copy comparison table showing improvements to the LazyCard landing screen: headline, value props list, acceptance copy, and CTA button"`
- **Content:** Before/After table with four rows (landing headline, value props, acceptance copy, CTA); original copy shown with strikethrough; recommended copy alongside; reason column explaining the rationale
- **Notes:** Place after the intro paragraph about the copy review scope; this is the primary evidence of the work done

---

## Page Structure Reference

```
[Project Hero]
  01_cover_thumbnail.svg             ← full-width hero

[Section: Understanding Users]
  text paragraph (3 personas intro)
  02_user-personas_inline.svg        ← full content width

[Section: Mapping the User Journey]
  text intro
  03_user-journey_full-width.svg     ← full content width

[Section: Designs and Copy Review]
  text intro (what was reviewed)
  04_copy-review_full-width.svg      ← full content width
  text (final copy outcome)
```

---

## Design Tokens Used

| Token | Value |
|---|---|
| Background | `#FAFAFA` |
| Primary text | `#111111` |
| Muted text | `#737373` |
| Accent (coral) | `#FF4530` |
| Card background | `#F2F2F2` |
| Border | `#E0E0E0` |
| Cover background | `#1A1A2E` with purple gradient |
