# Assets — Building an In-App Chat Assistant

**Project slug:** `chatbot`
**Portfolio section:** Older Projects (LazyPay / PayU Finance)
**Website project page:** `/work/chatbot` or equivalent slug

---

## Naming Convention

All files follow the pattern: `{NN}_{role}_{display-hint}.svg`

| Part | Meaning |
|---|---|
| `NN` | Two-digit sequence number — defines the **order images appear** on the project page (01 = first/top) |
| `role` | What the image depicts (cover, research-data, framework, etc.) |
| `display-hint` | Suggested CSS display treatment: `thumbnail`, `inline`, `full-width` |

---

## Files — In Display Order

### `01_cover_thumbnail.svg`
- **Sequence:** 1 — first image on the page; also used as the project card thumbnail
- **Placement:** Project card grid (Work index page) + hero area at top of project detail page
- **Display:** Full-width hero, `max-height: 480px`, `object-fit: cover`
- **Alt text:** `"Branching chat decision tree interface showing the in-app support bot conversation flow"`
- **Content:** Dark-background illustration of a chat UI with branching decision tree; stats bar at bottom (50K+ queries/mo, 60% resolution target, 5 product lines, 2 months duration)
- **Notes:** Use as `thumbnail` field in `data/projects.ts`

### `02_research-data_inline.svg`
- **Sequence:** 2 — appears in the "Research & Data" section of the case study
- **Placement:** Inline within the "Gather Research & Data" section
- **Display:** Contained width, `max-width: 700px`, centred or left-aligned
- **Alt text:** `"Horizontal bar chart showing top call centre query categories: Account Related 21.1%, Loans and EMIs 14.6%, Charges and Fees 6.1%"`
- **Content:** Horizontal bar chart of top query categories used to define the chatbot's category tree
- **Notes:** Place immediately after the paragraph describing the data collection process

### `03_content-framework_inline.svg`
- **Sequence:** 3 — appears in the "Guidelines and Framework" section
- **Placement:** Inline within the content framework / guidelines section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Four framework principles: Empathetic tone, Co-operative, At most 3 options per node, User stays in control"`
- **Content:** Four equal-width cards showing the content framework principles with numbered indicators
- **Notes:** Place after the introductory paragraph about the guidelines, before listing individual principles as text

### `04_prototype-findings_inline.svg`
- **Sequence:** 4 — appears in the "Prototype and Test" section
- **Placement:** Inline within the prototype testing section
- **Display:** Full content width, `max-width: 800px`
- **Alt text:** `"Six findings from 10 user prototype sessions, including preference for use-case categorisation and requests for NLP and in-app ticket raising"`
- **Content:** 3×2 grid of finding tiles — 3 positive confirmations and 3 scope gaps identified
- **Notes:** Place after the paragraph describing the two prototypes tested; before discussing the final tree

---

## Page Structure Reference

```
[Project Hero]
  01_cover_thumbnail.svg          ← full-width hero

[Section: The Challenge]
  text only

[Section: Research & Data]
  text paragraph
  02_research-data_inline.svg     ← inline, max-width 700px

[Section: Guidelines & Framework]
  text paragraph
  03_content-framework_inline.svg ← full content width

[Section: Prototype & Test]
  text paragraph
  04_prototype-findings_inline.svg ← full content width

[Section: Final Tree & Designs]
  text only (screens confidential)
```

---

## Design Tokens Used

All SVGs use the portfolio design system:

| Token | Value |
|---|---|
| Background | `#FAFAFA` |
| Primary text | `#111111` |
| Muted text | `#737373` |
| Accent (coral) | `#FF4530` |
| Card background | `#F2F2F2` |
| Border | `#E0E0E0` |
| Cover background | `#1A1A2E` (deep navy) |
