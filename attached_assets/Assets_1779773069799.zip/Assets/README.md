# Portfolio Assets — Older Projects

This folder contains all visual assets for Mohana Das's older projects from LazyPay / PayU Finance (2021–2024). These are distinct from the current-job projects in `portfolio_v1.docx` and correspond to the projects documented in `portfolio_v2.docx`.

---

## Folder Structure

```
Assets/
├── README.md                  ← This file (top-level index)
├── chatbot/
│   ├── README.md              ← Placement instructions for the chatbot project
│   ├── 01_cover_thumbnail.svg
│   ├── 02_research-data_inline.svg
│   ├── 03_content-framework_inline.svg
│   └── 04_prototype-findings_inline.svg
├── lazycard/
│   ├── README.md
│   ├── 01_cover_thumbnail.svg
│   ├── 02_user-personas_inline.svg
│   ├── 03_user-journey_full-width.svg
│   └── 04_copy-review_full-width.svg
├── expense-mgmt/
│   ├── README.md
│   ├── 01_cover_thumbnail.svg
│   ├── 02_user-research-stats_inline.svg
│   └── 03_ia-framework_full-width.svg
└── repayments/
    ├── README.md
    ├── 01_cover_thumbnail.svg
    ├── 02_problem-data_inline.svg
    ├── 03_solution-strategy_full-width.svg
    └── 04_content-hierarchy_full-width.svg
```

---

## Naming Convention (All Subfolders)

Every SVG file is named: **`{NN}_{role}_{display-hint}.svg`**

| Segment | Description |
|---|---|
| `NN` | Zero-padded sequence number (`01`, `02` …). Defines the **exact order** images appear on the project detail page. Lower = higher on the page. `01` is always the hero/thumbnail. |
| `role` | Describes the content: `cover`, `research-data`, `content-framework`, `prototype-findings`, `user-personas`, `user-journey`, `copy-review`, `user-research-stats`, `ia-framework`, `problem-data`, `solution-strategy`, `content-hierarchy` |
| `display-hint` | How the image should be rendered in the website layout: `thumbnail` (also used as card thumbnail), `inline` (contained max-width within text flow), `full-width` (spans the full content column) |

---

## Project-to-Slug Mapping

| Folder | Project title | Recommended website slug |
|---|---|---|
| `chatbot/` | Building an In-App Chat Assistant | `chatbot` |
| `lazycard/` | UX Writing Review for LazyCard | `lazycard` |
| `expense-mgmt/` | Exploring Expense Management | `expense-mgmt` |
| `repayments/` | Improving Repayment Rates | `repayments` |

---

## Display Rules for Website Builder

When building the project detail pages (`/work/[slug]`), follow these rules:

1. **`01_cover_thumbnail.svg`** — always use as both:
   - The `thumbnail` image on the Work index project card
   - The full-width hero image at the top of the project detail page

2. **`_inline`** files — render inside the text flow at `max-width: 700–800px`. Left-align or centre depending on layout. Apply `border-radius: 8px` and a subtle `box-shadow` for card-like appearance.

3. **`_full-width`** files — render spanning the full content column width (`max-width: 800px` or the layout's `--content-width`). No additional card styling needed.

4. **Sequence numbers** define scroll order: `01` appears first (top), `04` appears last (bottom).

5. **Each subfolder's `README.md`** contains the exact placement instructions, alt text, and page structure map for that specific project. Always read it when building the project page.

---

## Design System

All SVGs use the portfolio's design tokens:

| Token | Value |
|---|---|
| Background | `#FAFAFA` |
| Primary text | `#111111` |
| Muted text | `#737373` |
| Accent (coral) | `#FF4530` |
| Card fill | `#F2F2F2` |
| Border | `#E0E0E0` |
| White | `#FFFFFF` |

Cover images (always `01_cover_thumbnail.svg`) use dark backgrounds unique to each project:
- `chatbot`: `#1A1A2E` (deep navy)
- `lazycard`: `#1A1A2E` / `#2D1B3D` (navy-purple gradient)
- `expense-mgmt`: `#0D1F0D` (dark green)
- `repayments`: `#2A0A06` (dark red-brown)

---

## Asset Format

All files are `.svg` (Scalable Vector Graphics):
- Resolution-independent — renders crisply on any screen density
- No rasterisation needed; use directly in `<img>` tags or as CSS `background-image`
- Recommended: serve from `/public/images/projects/{slug}/` in the Next.js app router structure
